/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author cesar
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("1ra instancia creada");
        Automovil miAuto = new Automovil("Gasolina", 1.8, "A002", "Toyota", "Corolla", "Sedán", 4, false);
        
        miAuto.encender();
        miAuto.acelerar();
        miAuto.desplazar();
        miAuto.trans_pasajero();
        miAuto.mostrarCoords();
        miAuto.frenar();
        miAuto.apagar();

        // Obtener valores con getters
        System.out.println("Tipo de motor: " + miAuto.getTipo_Motor());
        System.out.println("Volumen del cilindro: " + miAuto.getVolumenCilindro());
        System.out.println("Código: " + miAuto.getCodigo());
        System.out.println("Marca: " + miAuto.getMarca());
        System.out.println("Tipo: " + miAuto.getTipo());
        System.out.println("Número de llantas: " + miAuto.getNum_Llantas());
        System.out.println("¿Tiene remolque?: " + (miAuto.tiene_Remolque()? "Sí" : "No"));

    }
    
}
