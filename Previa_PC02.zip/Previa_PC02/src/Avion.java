/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public class Avion extends VehiculoAereo{
    private int cant_Motores;
    private float distancia_MAX;

    public Avion(int cant_Motores, float distancia_MAX, float alturaMaxima, int cantPasajeros, String codigo, String marca, String tipo) {
        super(alturaMaxima, cantPasajeros, codigo, marca, tipo);
        this.cant_Motores = cant_Motores;
        this.distancia_MAX = distancia_MAX;
    }

   
    
    

    @Override
    public void volar() {
        System.out.println("El avion toma vuelo");
    }

    @Override
    public void planear() {
        System.out.println("El avion empieza a planear");
    }

    @Override
    public void mostrarCoords() {
        System.out.println("El avion muestra sus coordenadas");
    }

    @Override
    public void trans_pasajero() {
        System.out.println("El avion lleva pasajeros");
    }
    public void desplegarTrenAterrizaje(){
        System.out.println("Desplegando tren de aterrizaje");
    }
    public void ajustarAltitud(){
        System.out.println("El avion ajusta su altitud");
    }

    public int getCant_Motores() {
        return cant_Motores;
    }

    public void setCant_Motores(int cant_Motores) {
        this.cant_Motores = cant_Motores;
    }

    public float getDistancia_MAX() {
        return distancia_MAX;
    }

    public void setDistancia_MAX(float distancia_MAX) {
        this.distancia_MAX = distancia_MAX;
    }
    
}
