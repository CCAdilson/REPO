/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public abstract class VehiculoTerrestre extends Vehiculo implements IRemolque {
    private int num_Llantas;
    private boolean tiene_remolque;

    public VehiculoTerrestre(String codigo, String marca, String modelo, String tipo, int num_Llantas, boolean tiene_Remolque) {
        super(codigo, marca, tipo);  
        this.num_Llantas = num_Llantas;
        this.tiene_remolque = tiene_Remolque;
    }
    
    
    public abstract void desplazar();

    public int getNum_Llantas() {
        return num_Llantas;
    }

    public void setNum_Llantas(int num_Llantas) {
        this.num_Llantas = num_Llantas;
    }

    public boolean isTiene_remolque() {
        return tiene_remolque;
    }

    public void setTiene_remolque(boolean tiene_remolque) {
        this.tiene_remolque = tiene_remolque;
    }
    
    @Override
    public void remolcar() {
      if (tiene_remolque){
          System.out.println("Remolcando...");
      }else{
          System.out.println("No tiene remolque");
      }
    }
}
