/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public class Automovil extends VehiculoTerrestre implements IMotor {
    private String tipo_Motor;
    private double volumenCilindro;

        public Automovil(String tipo_Motor, double volumenCilindro, String codigo, String marca, String modelo, String tipo, int num_Llantas, boolean tiene_Remolque) {
            super(codigo, marca, modelo, tipo, num_Llantas, tiene_Remolque);
            this.tipo_Motor = tipo_Motor;
            this.volumenCilindro = volumenCilindro;
    }
        public boolean tiene_Remolque() {
            return isTiene_remolque();
        }
    
    @Override
    public void encender() {
        System.out.println("Automovil encendido");
    }

    @Override
    public void apagar() {
        System.out.println("Automovil apagado");
    }

    @Override
    public void frenar() {
         System.out.println("Automovil frenando");
    }
    

    @Override
    public void desplazar() {
        System.out.println("Automovil desplanzandose");
    }

    @Override
    public void trans_pasajero() {
        System.out.println("Automovil transportando pasajeros");
    }

    @Override
    public void mostrarCoords() {
        System.out.println("El automovil muestra las coordenadas");
    }

    @Override
    public void acelerar() {
        System.out.println("Automovil acelerando");
    }

    public String getTipo_Motor() {
        return tipo_Motor;
    }

    public void setTipo_Motor(String tipo_Motor) {
        this.tipo_Motor = tipo_Motor;
    }

    public double getVolumenCilindro() {
        return volumenCilindro;
    }

    public void setVolumenCilindro(double volumenCilindro) {
        this.volumenCilindro = volumenCilindro;
    }

    
    
}
