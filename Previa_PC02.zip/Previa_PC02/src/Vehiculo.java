/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public abstract class Vehiculo {
    private String codigo;
    private String marca;
    private String tipo;

    public Vehiculo(String codigo, String marca, String tipo) {
        this.codigo = codigo;
        this.marca = marca;
        this.tipo = tipo;
    }
    
    
    public abstract void mostrarCoords();
    public abstract void trans_pasajero();
    
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
    
    

