/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public class Helicoptero extends VehiculoAereo{
    private int numHelices;
    private int cant_Pasajeros;

    public Helicoptero(int numHelices, int cant_Pasajeros, float alturaMaxima, int cantPasajeros, String codigo, String marca, String tipo) {
        super(alturaMaxima, cantPasajeros, codigo, marca, tipo);
        this.numHelices = numHelices;
        this.cant_Pasajeros = cant_Pasajeros;
    }

    
    
    

    @Override
    public void volar() {
         System.out.println("El helicoptero alza el vuelo");
    }

    @Override
    public void planear() {
        System.out.println("El helicoptero empieza a planear");
    }

    @Override
    public void mostrarCoords() {
        System.out.println("El helicoptero muestra las coordenadas");
    }

    @Override
    public void trans_pasajero() {
        System.out.println("El helicoptero transporta a los pasajeros");
    }
    public void desegarVerticalmente(){
        System.out.println("El helicoptero despega verticalmente");
    }
    public void rotarHelice(){
        System.out.println("El helicoptera empieza a rotar sus helices");
    }

    public int getNumHelices() {
        return numHelices;
    }

    public void setNumHelices(int numHelices) {
        this.numHelices = numHelices;
    }

    public int getCant_Pasajeros() {
        return cant_Pasajeros;
    }

    public void setCant_Pasajeros(int cant_Pasajeros) {
        this.cant_Pasajeros = cant_Pasajeros;
    }
    
}
