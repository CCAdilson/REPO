/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public abstract class VehiculoAereo extends Vehiculo {
    private float alturaMaxima;
    private int cantPasajeros;

    public VehiculoAereo(float alturaMaxima, int cantPasajeros, String codigo, String marca, String tipo) {
        super(codigo, marca, tipo);
        this.alturaMaxima = alturaMaxima;
        this.cantPasajeros = cantPasajeros;
    }
    
    public abstract void volar();
    public abstract void planear();

    public float getAlturaMaxima() {
        return alturaMaxima;
    }

    public void setAlturaMaxima(float alturaMaxima) {
        this.alturaMaxima = alturaMaxima;
    }

    public int getCantPasajeros() {
        return cantPasajeros;
    }

    public void setCantPasajeros(int cantPasajeros) {
        this.cantPasajeros = cantPasajeros;
    }

    
}
