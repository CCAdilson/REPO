/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cesar
 */
public class Motocicleta extends VehiculoTerrestre implements IMotor{
    private float autonomia;
    private float cilindrada;

    public Motocicleta(float autonomia, float cilindrada, String codigo, String marca, String modelo, String tipo, int num_Llantas, boolean tiene_Remolque) {
        super(codigo, marca, modelo, tipo, num_Llantas, tiene_Remolque);
        this.autonomia = autonomia;
        this.cilindrada = cilindrada;
    }


    @Override
    public void desplazar() {
        System.out.println("Motocicleta desplazandose");
    }

    @Override
    public void trans_pasajero() {
        System.out.println("Motocicleta transportando pasajero");
    }

    @Override
    public void mostrarCoords() {
        System.out.println("Motocicleta mostrando las coordenadas");
    }

    @Override
    public void encender() {
        System.out.println("La motocicleta enciende");
    }

    @Override
    public void apagar() {
        System.out.println("La motocicleta se apaga");
    }

    @Override
    public void frenar() {
        System.out.println("La motocicleta frena");
    }

    @Override
    public void acelerar() {
        System.out.println("la motocicleta acelera");
    }

    public float getAutonomia() {
        return autonomia;
    }

    public void setAutonomia(float autonomia) {
        this.autonomia = autonomia;
    }

    public float getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(float cilindrada) {
        this.cilindrada = cilindrada;
    }
    
}
